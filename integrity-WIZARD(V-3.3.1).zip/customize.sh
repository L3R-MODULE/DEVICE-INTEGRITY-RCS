# shellcheck disable=SC2034
SKIPUNZIP=1

DEBUG=false
SONAME=tricky_store
SUPPORTED_ABIS="arm64 x64 arm"
MIN_SDK=31

ui_print "cleaning environment"
rm -r /data/adb/tricky_store
rm -r /data/adb/modules/playintegrityfix
rm -r /data/adb/modules/playintegrityfork
rm -r /data/adb/modules/tricky_store
rm -r /data/adb/modules/playcurl
rm -r /data/adb/modules/sensitive_props
rm -r /data/adb/modules/integrity-WIZARD
rm -r /data/adb/modules/FrameworkPatcherGo

if [ "$BOOTMODE" ] && [ "$KSU" ]; then
  ui_print "- Installing from KernelSU app"
  ui_print "- KernelSU version: $KSU_KERNEL_VER_CODE (kernel) + $KSU_VER_CODE (ksud)"
  if [ "$(which magisk)" ]; then
    ui_print "*********************************************************"
    ui_print "! Multiple root implementation is NOT supported!"
    ui_print "! Please uninstall Magisk before installing Tricky Store"
    abort    "*********************************************************"
  fi
elif [ "$BOOTMODE" ] && [ "$MAGISK_VER_CODE" ]; then
  ui_print "- Installing from Magisk app"
else
  ui_print "*********************************************************"
  ui_print "! Install from recovery is not supported"
  ui_print "! Please install from KernelSU or Magisk app"
  abort    "*********************************************************"
fi

VERSION=$(grep_prop version "${TMPDIR}/module.prop")
ui_print "- Installing $SONAME $VERSION"

# check architecture
support=false
for abi in $SUPPORTED_ABIS
do
  if [ "$ARCH" == "$abi" ]; then
    support=true
  fi
done
if [ "$support" == "false" ]; then
  abort "! Unsupported platform: $ARCH"
else
  ui_print "- Device platform: $ARCH"
fi

# check android
if [ "$API" -lt $MIN_SDK ]; then
  ui_print "! Unsupported sdk: $API"
  abort "! Minimal supported sdk is $MIN_SDK"
else
  ui_print "- Device sdk: $API"
fi

ui_print "- Extracting verify.sh"
unzip -o "$ZIPFILE" 'verify.sh' -d "$TMPDIR" >&2
if [ ! -f "$TMPDIR/verify.sh" ]; then
  ui_print "*********************************************************"
  ui_print "! Unable to extract verify.sh!"
  ui_print "! This zip may be corrupted, please try downloading again"
  abort    "*********************************************************"
fi
. "$TMPDIR/verify.sh"
extract "$ZIPFILE" 'customize.sh'  "$TMPDIR/.vunzip"
extract "$ZIPFILE" 'verify.sh'     "$TMPDIR/.vunzip"

ui_print "- Extracting module files"
extract "$ZIPFILE" 'module.prop'     "$MODPATH"
extract "$ZIPFILE" 'post-fs-data.sh' "$MODPATH"
extract "$ZIPFILE" 'service.sh'      "$MODPATH"
extract "$ZIPFILE" 'oem.rc'      "$MODPATH"
extract "$ZIPFILE" 'common_func.sh'      "$MODPATH"
extract "$ZIPFILE" 'utils.sh'      "$MODPATH"
extract "$ZIPFILE" 'system.prop'      "$MODPATH"
extract "$ZIPFILE" 'service.apk'     "$MODPATH"
extract "$ZIPFILE" 'sepolicy.rule'   "$MODPATH"
extract "$ZIPFILE" 'daemon'          "$MODPATH"
chmod 755 "$MODPATH/daemon"

mkdir "$MODPATH/zygisk"

if [ "$ARCH" = "x64" ]; then
  ui_print "- Extracting x64 libraries"
  extract "$ZIPFILE" "lib/x86_64/lib$SONAME.so" "$MODPATH" true
  extract "$ZIPFILE" "lib/x86_64/libinject.so" "$MODPATH" true
  extract "$ZIPFILE" "lib/x86_64/libtszygisk.so" "$MODPATH/zygisk" true
  mv "$MODPATH/zygisk/libtszygisk.so" "$MODPATH/zygisk/x86_64.so"
elif [ "$ARCH" = "arm" ]; then
  ui_print "- Extracting arm libraries"
  extract "$ZIPFILE" "lib/armeabi-v7a/lib$SONAME.so" "$MODPATH" true
  extract "$ZIPFILE" "lib/armeabi-v7a/libinject.so" "$MODPATH" true
  extract "$ZIPFILE" "lib/armeabi-v7a/libtszygisk.so" "$MODPATH/zygisk" true
  mv "$MODPATH/zygisk/libtszygisk.so" "$MODPATH/zygisk/armeabi-v7a.so"
else
  ui_print "- Extracting arm64 libraries"
  extract "$ZIPFILE" "lib/arm64-v8a/lib$SONAME.so" "$MODPATH" true
  extract "$ZIPFILE" "lib/arm64-v8a/libinject.so" "$MODPATH" true
  extract "$ZIPFILE" "lib/arm64-v8a/libtszygisk.so" "$MODPATH/zygisk" true
  mv "$MODPATH/zygisk/libtszygisk.so" "$MODPATH/zygisk/arm64-v8a.so"
fi

mv "$MODPATH/libinject.so" "$MODPATH/inject"
chmod 755 "$MODPATH/inject"

CONFIG_DIR=/data/adb/tricky_store
if [ ! -d "$CONFIG_DIR" ]; then
  ui_print "- Creating configuration directory"
  mkdir -p "$CONFIG_DIR"
fi
if [ ! -f "$CONFIG_DIR/keybox.xml" ]; then
  ui_print "- Adding default software keybox"
  extract "$ZIPFILE" 'keybox.xml' "$TMPDIR"
  mv "$TMPDIR/keybox.xml" "$CONFIG_DIR/keybox.xml"
fi
if [ ! -f "$CONFIG_DIR/target.txt" ]; then
  ui_print "- Adding default target scope"
  extract "$ZIPFILE" 'target.txt' "$TMPDIR"
  mv "$TMPDIR/target.txt" "$CONFIG_DIR/target.txt"
fi
if [ ! -f "$CONFIG_DIR/UpdateTargets.sh" ]; then
  ui_print "- add all apps target.txt script"
  extract "$ZIPFILE" 'UpdateTargets.sh' "$TMPDIR"
  mv "$TMPDIR/UpdateTargets.sh" "$CONFIG_DIR/UpdateTargets.sh"
fi
if [ ! -f "$CONFIG_DIR/tee_status" ]; then
  ui_print "- TEE auto repair..."
  extract "$ZIPFILE" 'tee_status' "$TMPDIR"
  mv "$TMPDIR/tee_status" "$CONFIG_DIR/tee_status"
fi

# Check custom fingerprint
if [ -f "/data/adb/pif.json" ]; then
  mv -f "/data/adb/pif.json" "/data/adb/pif.json.old"
  ui_print "- Backup custom pif.json"
fi

ui_print "- Adding pif json"
extract "$ZIPFILE" 'pif.json' "$TMPDIR"
mv -f "$TMPDIR/pif.json" "$CONFIG_DIR/pif.json"

if [ -d "/data/adb/modules/playintegrityfix" ]; then
  ui_print "- PIF module will be removed on next reboot"
  touch "/data/adb/modules/playintegrityfix/remove"
fi

su -c pm list packages | awk -F: '{print $2}' > /data/adb/tricky_store/target.txt

su -c sleep 2 | echo "handling target.txt please wait..."
 
su -c sed -i 's/$/!/g' /data/adb/tricky_store/target.txt

echo "success, all of your device apps were spoofed, and added to targets!"
